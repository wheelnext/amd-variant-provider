# noop
# "pyrsmi" is supposed to be the equivalent of NVIDIA "pynvml".
